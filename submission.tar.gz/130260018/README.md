# CS726-Assignment
The final model is saved in the file model.ckpt. The file devnflow.py was the one used to train the model and pre-process.py was used to pre-process all training and test images. These scripts need specific folders containing the images to exist in a folder ‘devnagri’, which resides in the same directory as these scripts.


The code depends on libraries scikit-image, tensorflow and numpy.
